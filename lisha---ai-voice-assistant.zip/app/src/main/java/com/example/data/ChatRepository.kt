package com.example.data

import kotlinx.coroutines.flow.Flow

class ChatRepository(private val dao: ChatMessageDao) {
    val allMessages: Flow<List<ChatMessage>> = dao.getAllMessages()

    suspend fun insert(message: ChatMessage): Long {
        return dao.insertMessage(message)
    }

    suspend fun clearHistory() {
        dao.clearAllMessages()
    }
}
