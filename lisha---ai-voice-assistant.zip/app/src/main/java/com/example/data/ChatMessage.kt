package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String, // "user" or "lisha"
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val language: String = "hinglish", // "hi", "en", "hinglish"
    val isVoice: Boolean = true
)
