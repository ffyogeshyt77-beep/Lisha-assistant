package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LishaColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = VoidBackground,
    primaryContainer = GlassSurface,
    onPrimaryContainer = CyberCyan,
    secondary = NeonPurple,
    onSecondary = TextPrimary,
    secondaryContainer = VoidSurfaceVariant,
    onSecondaryContainer = TextPrimary,
    tertiary = CyberEmerald,
    onTertiary = VoidBackground,
    background = VoidBackground,
    onBackground = TextPrimary,
    surface = VoidSurface,
    onSurface = TextPrimary,
    surfaceVariant = VoidSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder
)

@Composable
fun LishaTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = VoidBackground.toArgb()
            window.navigationBarColor = VoidBackground.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = LishaColorScheme,
        typography = Typography,
        content = content
    )
}
