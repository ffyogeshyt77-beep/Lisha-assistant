package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiRepository
import com.example.ai.LishaLocalEngine
import com.example.data.ChatMessage
import com.example.data.ChatRepository
import com.example.data.LishaDatabase
import com.example.voice.SpeechManager
import com.example.voice.VoiceRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LishaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = LishaDatabase.getDatabase(application)
    private val repository = ChatRepository(db.chatMessageDao())
    private val localEngine = LishaLocalEngine()
    private val geminiRepository = GeminiRepository()

    val speechManager = SpeechManager(application)
    val voiceRecognizer = VoiceRecognizer(application)

    val messages = repository.allMessages

    private val _isOnlineAiMode = MutableStateFlow(geminiRepository.isApiKeyAvailable())
    val isOnlineAiMode: StateFlow<Boolean> = _isOnlineAiMode.asStateFlow()

    private val _isApiKeyConfigured = MutableStateFlow(geminiRepository.isApiKeyAvailable())
    val isApiKeyConfigured: StateFlow<Boolean> = _isApiKeyConfigured.asStateFlow()

    val isSpeaking = speechManager.isSpeaking
    val isListening = voiceRecognizer.isListening
    val rmsDb = voiceRecognizer.rmsDb

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("auto") // "auto", "hi", "en", "hinglish"
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        viewModelScope.launch {
            voiceRecognizer.recognizedText.collect { recognized ->
                if (!recognized.isNullOrBlank()) {
                    sendMessage(recognized, isVoice = true)
                    voiceRecognizer.clearState()
                }
            }
        }

        viewModelScope.launch {
            voiceRecognizer.error.collect { err ->
                if (err != null) {
                    _errorMessage.value = err
                }
            }
        }

        // Welcome greeting if chat is empty
        viewModelScope.launch {
            repository.allMessages.collect { list ->
                if (list.isEmpty()) {
                    val welcomeMsg = ChatMessage(
                        sender = "lisha",
                        message = "Namaste! Main LISHA hoon, aapki AI Voice Assistant. Batiye main aapki kya help kar sakti hoon?",
                        language = "hinglish",
                        isVoice = false
                    )
                    repository.insert(welcomeMsg)
                }
            }
        }
    }

    fun startListening() {
        _errorMessage.value = null
        if (isSpeaking.value) {
            speechManager.stop()
        }
        val langCode = when (_selectedLanguage.value) {
            "hi" -> "hi-IN"
            "en" -> "en-IN"
            else -> "hi-IN"
        }
        voiceRecognizer.startListening(langCode)
    }

    fun stopListening() {
        voiceRecognizer.stopListening()
    }

    fun sendMessage(userText: String, isVoice: Boolean = false) {
        val cleanText = userText.trim()
        if (cleanText.isEmpty()) return

        viewModelScope.launch {
            // Save user message
            val userMsg = ChatMessage(
                sender = "user",
                message = cleanText,
                language = _selectedLanguage.value,
                isVoice = isVoice
            )
            repository.insert(userMsg)

            _isProcessing.value = true
            _errorMessage.value = null

            // Determine if using Online Gemini or Local Engine
            if (_isOnlineAiMode.value && geminiRepository.isApiKeyAvailable()) {
                val result = geminiRepository.generateResponse(cleanText)
                result.onSuccess { replyText ->
                    saveAndSpeakResponse(replyText, "hinglish")
                }.onFailure { err ->
                    // Fallback to local engine on error
                    val localResult = localEngine.processCommand(cleanText, _selectedLanguage.value)
                    val fallbackNotice = "${localResult.text}\n\n(Note: Gemini online failed: ${err.localizedMessage ?: "Network error"}. Answered via Local AI Engine)"
                    saveAndSpeakResponse(fallbackNotice, localResult.language)
                }
            } else {
                val localResult = localEngine.processCommand(cleanText, _selectedLanguage.value)
                saveAndSpeakResponse(localResult.text, localResult.language)
            }

            _isProcessing.value = false
        }
    }

    private suspend fun saveAndSpeakResponse(responseStr: String, language: String) {
        val lishaMsg = ChatMessage(
            sender = "lisha",
            message = responseStr,
            language = language,
            isVoice = true
        )
        repository.insert(lishaMsg)

        // Read out loud with TextToSpeech
        speechManager.speak(responseStr, language)
    }

    fun speakText(text: String, language: String = "hinglish") {
        speechManager.speak(text, language)
    }

    fun stopSpeech() {
        speechManager.stop()
    }

    fun toggleOnlineAiMode(enabled: Boolean) {
        _isOnlineAiMode.value = enabled
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
    }

    fun setSpeechRate(rate: Float) {
        speechManager.speechRate = rate
    }

    fun setSpeechPitch(pitch: Float) {
        speechManager.speechPitch = pitch
    }

    fun toggleSettings(show: Boolean) {
        _showSettings.value = show
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            speechManager.stop()
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.shutdown()
        voiceRecognizer.stopListening()
    }
}
