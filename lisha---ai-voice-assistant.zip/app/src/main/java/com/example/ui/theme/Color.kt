package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic LISHA Dark Theme Palette
val VoidBackground = Color(0xFF0A0E17)
val VoidSurface = Color(0xFF121826)
val VoidSurfaceVariant = Color(0xFF1B2436)

val CyberCyan = Color(0xFF00F0FF)
val ElectricBlue = Color(0xFF1E90FF)
val NeonPurple = Color(0xFF9D4EDD)
val NeonPink = Color(0xFFFF2A85)
val CyberEmerald = Color(0xFF00E676)
val BrightAmber = Color(0xFFFFB703)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val GlassBorder = Color(0x3300F0FF)
val GlassSurface = Color(0x1A00F0FF)
