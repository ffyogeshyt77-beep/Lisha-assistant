package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import kotlin.math.sin

@Composable
fun FuturisticAiOrb(
    isListening: Boolean,
    isSpeaking: Boolean,
    isProcessing: Boolean,
    rmsDb: Float,
    onOrbClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbTransition")

    // Rotation angle for the energy rings
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation"
    )

    // Pulse scale for the inner aura
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse"
    )

    // Dynamic color glow depending on state
    val coreGlowColors = when {
        isListening -> listOf(NeonPink, CyberCyan, ElectricBlue)
        isSpeaking -> listOf(CyberEmerald, CyberCyan, NeonPurple)
        isProcessing -> listOf(NeonPurple, ElectricBlue, CyberCyan)
        else -> listOf(CyberCyan, ElectricBlue, NeonPurple)
    }

    val stateLabel = when {
        isListening -> "Listening to you..."
        isProcessing -> "LISHA Thinking..."
        isSpeaking -> "LISHA Speaking..."
        else -> "Tap to Speak"
    }

    val stateIcon = when {
        isListening -> Icons.Default.Mic
        isSpeaking -> Icons.Default.VolumeUp
        isProcessing -> Icons.Default.GraphicEq
        else -> Icons.Default.Mic
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.padding(vertical = 12.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onOrbClick
                )
                .testTag("lisha_ai_orb")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2, size.height / 2)
                val baseRadius = size.width / 2.8f
                val currentPulse = if (isListening) pulseScale + (rmsDb * 0.03f) else if (isSpeaking) pulseScale + 0.05f else pulseScale

                // 1. Outer Holographic Pulse Ring
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(coreGlowColors[0].copy(alpha = 0.35f), Color.Transparent),
                        center = center,
                        radius = baseRadius * 1.5f * currentPulse
                    ),
                    radius = baseRadius * 1.4f * currentPulse,
                    center = center
                )

                // 2. Outer Dashed Tech Ring (Rotating Clockwise)
                rotate(rotationAngle, center) {
                    drawCircle(
                        color = coreGlowColors[0].copy(alpha = 0.6f),
                        radius = baseRadius * 1.25f,
                        center = center,
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 25f), 0f)
                        )
                    )
                }

                // 3. Inner Dashed Tech Ring (Rotating Counter-Clockwise)
                rotate(-rotationAngle * 1.5f, center) {
                    drawCircle(
                        color = coreGlowColors[1].copy(alpha = 0.7f),
                        radius = baseRadius * 1.05f,
                        center = center,
                        style = Stroke(
                            width = 3.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 20f), 0f)
                        )
                    )
                }

                // 4. Central Core Sphere
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.9f),
                            coreGlowColors[0],
                            coreGlowColors[1],
                            coreGlowColors[2].copy(alpha = 0.8f)
                        ),
                        center = center,
                        radius = baseRadius * currentPulse
                    ),
                    radius = baseRadius * currentPulse,
                    center = center
                )

                // 5. Reactive Waveform Bars (When listening or speaking)
                if (isListening || isSpeaking || isProcessing) {
                    val numBars = 12
                    val angleStep = (2 * Math.PI / numBars)
                    for (i in 0 until numBars) {
                        val angle = i * angleStep
                        val barLength = if (isListening) (10 + (rmsDb * 8f) + (sin(i + rotationAngle) * 6f)).dp.toPx()
                        else if (isSpeaking) (12 + (sin(i * 1.2 + rotationAngle * 0.1) * 12f)).dp.toPx()
                        else (8 + (sin(i.toDouble()) * 4f)).dp.toPx()

                        val startX = center.x + (baseRadius * 0.95f) * kotlin.math.cos(angle).toFloat()
                        val startY = center.y + (baseRadius * 0.95f) * kotlin.math.sin(angle).toFloat()
                        val endX = center.x + (baseRadius * 0.95f + barLength) * kotlin.math.cos(angle).toFloat()
                        val endY = center.y + (baseRadius * 0.95f + barLength) * kotlin.math.sin(angle).toFloat()

                        drawLine(
                            color = if (i % 2 == 0) coreGlowColors[0] else coreGlowColors[1],
                            start = Offset(startX, startY),
                            end = Offset(endX, endY),
                            strokeWidth = 3.dp.toPx()
                        )
                    }
                }
            }

            // Center Icon inside orb
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                modifier = Modifier
                    .size(56.dp)
                    .shadow(12.dp, CircleShape)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        imageVector = stateIcon,
                        contentDescription = stateLabel,
                        tint = coreGlowColors[0],
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // State indicator badge below orb
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
            border = Stroke border@{ width = 1.dp.toPx(); pathEffect = null }.let { null },
            modifier = Modifier.padding(horizontal = 16.dp)
        ) {
            Text(
                text = stateLabel,
                color = if (isListening) NeonPink else if (isSpeaking) CyberEmerald else CyberCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
    }
}
