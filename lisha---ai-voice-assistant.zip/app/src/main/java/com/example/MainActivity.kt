package com.example

import android.Manifest
import android.content.contentValuesOf
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.LishaViewModel
import com.example.ui.components.FuturisticAiOrb
import com.example.ui.components.LishaHeader
import com.example.ui.components.MessageBubble
import com.example.ui.components.QuickCommandChips
import com.example.ui.components.SettingsModal
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.LishaTheme
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.VoidBackground
import com.example.ui.theme.VoidSurface

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LishaTheme {
                LishaAppScreen()
            }
        }
    }
}

@Composable
fun LishaAppScreen(viewModel: LishaViewModel = viewModel()) {
    val context = LocalContext.current

    val messages by viewModel.messages.collectAsState(initial = emptyList())
    val isListening by viewModel.isListening.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val rmsDb by viewModel.rmsDb.collectAsState()
    val isOnlineMode by viewModel.isOnlineAiMode.collectAsState()
    val isApiKeyConfigured by viewModel.isApiKeyConfigured.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val showSettings by viewModel.showSettings.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Audio Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        } else {
            Toast.makeText(context, "Microphone permission required for LISHA voice commands", Toast.LENGTH_SHORT).show()
        }
    }

    // Scroll to latest message when new message arrives
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding())) {
                LishaHeader(
                    isOnlineMode = isOnlineMode,
                    selectedLanguage = selectedLanguage,
                    onLanguageChange = { viewModel.setLanguage(it) },
                    onSettingsClick = { viewModel.toggleSettings(true) },
                    onClearHistoryClick = { viewModel.clearHistory() }
                )
            }
        },
        containerColor = VoidBackground,
        modifier = Modifier
            .fillMaxSize()
            .testTag("lisha_app_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            // Futuristic Holographic Orb Visualizer
            FuturisticAiOrb(
                isListening = isListening,
                isSpeaking = isSpeaking,
                isProcessing = isProcessing,
                rmsDb = rmsDb,
                onOrbClick = {
                    if (isSpeaking) {
                        viewModel.stopSpeech()
                    } else if (isListening) {
                        viewModel.stopListening()
                    } else {
                        val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                            viewModel.startListening()
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            // Error Banner if speech or Gemini error occurs
            AnimatedVisibility(visible = errorMessage != null) {
                if (errorMessage != null) {
                    Surface(
                        color = NeonPink.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonPink),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearErrorMessage() },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss error",
                                    tint = TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Chat Messages Stream
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    MessageBubble(
                        message = msg,
                        onSpeakClick = { text, lang -> viewModel.speakText(text, lang) }
                    )
                }
            }

            // Quick Voice Command Chips
            QuickCommandChips(
                onChipClick = { prompt ->
                    val cleanPrompt = prompt.replace(Regex("[^a-zA-Z0-9\\s\\u0900-\\u097F?]"), "").trim()
                    viewModel.sendMessage(cleanPrompt, isVoice = false)
                }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Bottom Voice & Text Controls Dock
            Surface(
                color = VoidSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Text Input Field for quiet environment typing
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("Ask LISHA in Hindi/English...", color = TextMuted, fontSize = 13.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = GlassSurface,
                            unfocusedContainerColor = GlassSurface,
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (textInput.isNotBlank()) {
                                    viewModel.sendMessage(textInput, isVoice = false)
                                    textInput = ""
                                }
                            }
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("text_command_input")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (textInput.isNotBlank()) {
                        // Send Text Button
                        IconButton(
                            onClick = {
                                viewModel.sendMessage(textInput, isVoice = false)
                                textInput = ""
                            },
                            modifier = Modifier.testTag("send_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send Command",
                                tint = CyberCyan
                            )
                        }
                    } else {
                        // Glowing Voice Microphone Floating Action Button
                        FloatingActionButton(
                            onClick = {
                                if (isSpeaking) {
                                    viewModel.stopSpeech()
                                } else if (isListening) {
                                    viewModel.stopListening()
                                } else {
                                    val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                                    if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                                        viewModel.startListening()
                                    } else {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            },
                            shape = CircleShape,
                            containerColor = if (isListening) NeonPink else if (isSpeaking) CyberEmerald else NeonPurple,
                            contentColor = TextPrimary,
                            elevation = FloatingActionButtonDefaults.elevation(8.dp),
                            modifier = Modifier
                                .size(52.dp)
                                .testTag("mic_button")
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.MicOff else if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.Mic,
                                contentDescription = "Voice Input",
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }
        }

        // Settings Modal Sheet
        if (showSettings) {
            SettingsModal(
                isOnlineAiMode = isOnlineMode,
                isApiKeyConfigured = isApiKeyConfigured,
                onToggleOnlineAi = { viewModel.toggleOnlineAiMode(it) },
                onSpeechRateChange = { viewModel.setSpeechRate(it) },
                onSpeechPitchChange = { viewModel.setSpeechPitch(it) },
                onTestVoice = {
                    viewModel.speakText("Namaste! Main LISHA hoon, aapki futuristic AI voice assistant.", selectedLanguage)
                },
                onDismiss = { viewModel.toggleSettings(false) }
            )
        }
    }
}
