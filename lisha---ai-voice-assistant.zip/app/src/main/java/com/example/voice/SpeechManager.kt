package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class SpeechManager(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized

    var speechRate: Float = 1.0f
    var speechPitch: Float = 1.0f

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            _isInitialized.value = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
        } else {
            Log.e("SpeechManager", "TTS Initialization failed with status: $status")
        }
    }

    fun speak(text: String, language: String = "hinglish") {
        if (!_isInitialized.value || tts == null) return

        tts?.stop()
        tts?.setSpeechRate(speechRate)
        tts?.setPitch(speechPitch)

        val locale = when (language) {
            "hi" -> Locale("hi", "IN")
            "en" -> Locale("en", "IN")
            else -> {
                // For hinglish, prefer Hindi if available, else English
                val hiLocale = Locale("hi", "IN")
                if (tts?.isLanguageAvailable(hiLocale) == TextToSpeech.LANG_AVAILABLE) {
                    hiLocale
                } else {
                    Locale.getDefault()
                }
            }
        }

        try {
            val langResult = tts?.setLanguage(locale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
        } catch (e: Exception) {
            tts?.setLanguage(Locale.US)
        }

        val utteranceId = "LISHA_TTS_${System.currentTimeMillis()}"
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
