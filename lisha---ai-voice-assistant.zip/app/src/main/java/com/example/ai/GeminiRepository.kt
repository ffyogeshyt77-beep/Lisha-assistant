package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiRepository {

    private val systemPrompt = """
        You are LISHA, a friendly, intelligent personal AI voice assistant.
        You naturally understand Hindi, English, and Hinglish.
        Provide concise, polite, natural, and conversational spoken answers (1 to 3 sentences maximum).
        If the user speaks in Hindi or Hinglish, respond in warm, natural Hinglish or clear Hindi as appropriate.
        Do not use markdown lists, code blocks, or heavy formatting because your text will be spoken out loud via Text-to-Speech.
    """.trimIndent()

    fun isApiKeyAvailable(): Boolean {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            key.isNotBlank() && key != "MY_GEMINI_API_KEY"
        } catch (e: Exception) {
            false
        }
    }

    suspend fun generateResponse(userInput: String): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(IllegalStateException("Gemini API key is not configured in Secrets."))
        }

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(parts = listOf(GeminiPart(text = userInput)))
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemPrompt))
            )
        )

        try {
            val response = GeminiClient.apiService.generateContent(apiKey, request)
            if (response.error != null) {
                return@withContext Result.failure(Exception(response.error.message ?: "Gemini API Error"))
            }

            val responseText = response.candidates
                ?.firstOrNull()
                ?.content
                ?.parts
                ?.firstOrNull()
                ?.text

            if (!responseText.isNullOrBlank()) {
                Result.success(responseText.trim())
            } else {
                Result.failure(Exception("Empty response from Gemini AI."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
