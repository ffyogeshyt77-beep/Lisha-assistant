package com.example.ai

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LishaLocalEngine {

    data class ResponseResult(
        val text: String,
        val language: String, // "hi", "en", "hinglish"
        val intent: String
    )

    fun processCommand(input: String, userLangPreference: String = "auto"): ResponseResult {
        val cleanInput = input.trim().lowercase(Locale.ROOT)

        // Detect language style
        val detectedLang = when {
            containsHindiCharacters(input) -> "hi"
            cleanInput.contains(Regex("\\b(kaise|kya|hai|hoon|tum|meri|namaste|sun|chutkula|mausam|samay|bolo)\\b")) -> "hinglish"
            else -> "en"
        }

        val targetLang = if (userLangPreference != "auto") userLangPreference else detectedLang

        // 1. Greetings
        if (cleanInput.contains(Regex("\\b(hello|hi|hey|namaste|suno|lisha|नमस्ते|हेलो)\\b"))) {
            return when (targetLang) {
                "hi" -> ResponseResult("नमस्ते! मैं लिषा हूँ, आपकी AI वॉयस असिस्टेंट। मैं आपकी क्या मदद कर सकती हूँ?", "hi", "GREETING")
                "en" -> ResponseResult("Hello! I am LISHA, your personal AI voice assistant. How can I assist you today?", "en", "GREETING")
                else -> ResponseResult("Namaste! Main LISHA hoon, aapki AI Voice Assistant. Batiye main aapki kya help kar sakti hoon?", "hinglish", "GREETING")
            }
        }

        // 2. Identity / Who are you
        if (cleanInput.contains(Regex("\\b(who are you|tum kaun ho|kaun ho|who created|tumhe kisine banaya|tell me about yourself|kaun h|kaun ho tum)\\b"))) {
            return when (targetLang) {
                "hi" -> ResponseResult("मैं लिषा हूँ, एक स्मार्ट AI वॉयस असिस्टेंट जो हिंदी और अंग्रेजी दोनों समझती है।", "hi", "IDENTITY")
                "en" -> ResponseResult("I am LISHA, a futuristic AI voice assistant designed to understand Hindi, English, and Hinglish.", "en", "IDENTITY")
                else -> ResponseResult("Main LISHA hoon, aapki personal AI Voice Assistant. Main Hindi, English aur Hinglish sab samajhti hoon!", "hinglish", "IDENTITY")
            }
        }

        // 3. How are you
        if (cleanInput.contains(Regex("\\b(kaise ho|kya haal|how are you|kaisa hai|sab theek)\\b"))) {
            return when (targetLang) {
                "hi" -> ResponseResult("मैं बिल्कुल बढ़िया और तैयार हूँ! आप कैसे हैं?", "hi", "STATUS")
                "en" -> ResponseResult("I am functioning at full capacity and ready to assist you! How are you doing?", "en", "STATUS")
                else -> ResponseResult("Main bilkul mast aur ready hoon! Aap bataiye, aapka din kaisa chal raha hai?", "hinglish", "STATUS")
            }
        }

        // 4. Time and Date
        if (cleanInput.contains(Regex("\\b(time|samay|kitne baje|date|taarikh|aaj konsa din|clock)\\b"))) {
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
            val currentTime = timeFormat.format(Date())
            val currentDate = dateFormat.format(Date())

            return when (targetLang) {
                "hi" -> ResponseResult("अभी समय $currentTime हुआ है और आज $currentDate है।", "hi", "TIME")
                "en" -> ResponseResult("The current time is $currentTime, and today is $currentDate.", "en", "TIME")
                else -> ResponseResult("Abhi time $currentTime hua hai, aur aaj $currentDate hai.", "hinglish", "TIME")
            }
        }

        // 5. Jokes & Humor
        if (cleanInput.contains(Regex("\\b(joke|chutkula|hasao|funny|mzak)\\b"))) {
            val jokesHinglish = listOf(
                "Teacher: Newton ka chautha niyam batao? Student: Agar paper kathin ho to silently bahar nikal jao!",
                "Pappu: Yaar doctor ne mujhe meditation karne ko kaha hai. Friend: To kaisa lag raha hai? Pappu: Sone me maza aa raha hai!",
                "Computer: Enter new password. User: Mango. Computer: Password must have at least 8 characters. User: Mango_Banana_Apple!"
            )
            val jokesHindi = listOf(
                "शिक्षक: न्यूटन का नियम बताओ? छात्र: अगर पेपर कठिन हो, तो चुपचाप बाहर निकल जाओ!",
                "डॉक्टर: आपको आराम की सख्त ज़रूरत है। मरीज: ठीक है डॉक्टर साहब, मैं काम पर नहीं जाऊँगा!"
            )
            val jokesEn = listOf(
                "Why don't scientists trust atoms? Because they make up everything!",
                "What do you call a factory that makes okay products? A satisfactory!",
                "Why did the smartphone need glasses? Because it lost its contacts!"
            )

            return when (targetLang) {
                "hi" -> ResponseResult(jokesHindi.random(), "hi", "JOKE")
                "en" -> ResponseResult(jokesEn.random(), "en", "JOKE")
                else -> ResponseResult(jokesHinglish.random(), "hinglish", "JOKE")
            }
        }

        // 6. Weather Query
        if (cleanInput.contains(Regex("\\b(weather|mausam|barish|dhoop|temperature|thand|garmi)\\b"))) {
            return when (targetLang) {
                "hi" -> ResponseResult("आज का मौसम काफी सुहाना है। तापमान लगभग 26 डिग्री सेल्सियस है और हल्की हवाएं चल रही हैं।", "hi", "WEATHER")
                "en" -> ResponseResult("The current weather is pleasant with a temperature around 26 degrees Celsius and mild breeze.", "en", "WEATHER")
                else -> ResponseResult("Aaj mausam ekdam mast hai! Temperature around 26°C hai aur halki thandi hawa chal rahi hai.", "hinglish", "WEATHER")
            }
        }

        // 7. Capabilities / What can you do
        if (cleanInput.contains(Regex("\\b(kya kar sakti ho|what can you do|help|capabilities|madad|features)\\b"))) {
            return when (targetLang) {
                "hi" -> ResponseResult("मैं समय, तारीख, मौसम बता सकती हूँ, चुटकुले सुना सकती हूँ, गणितीय गणनाएं कर सकती हूँ और जेमिनी AI से ऑनलाइन सवालों के जवाब दे सकती हूँ!", "hi", "CAPABILITY")
                "en" -> ResponseResult("I can tell time, check weather, solve math calculations, entertain with jokes, and answer complex questions via online Gemini AI!", "en", "CAPABILITY")
                else -> ResponseResult("Main time, weather, jokes, math calculations bata sakti hoon aur Online Gemini AI mode me kisi bhi topic par baat kar sakti hoon!", "hinglish", "CAPABILITY")
            }
        }

        // 8. Math calculations (simple Regex match)
        val mathResult = trySolveMath(cleanInput)
        if (mathResult != null) {
            return when (targetLang) {
                "hi" -> ResponseResult("गणितीय उत्तर है: $mathResult", "hi", "MATH")
                "en" -> ResponseResult("The calculation result is: $mathResult", "en", "MATH")
                else -> ResponseResult("Aapka answer hai: $mathResult", "hinglish", "MATH")
            }
        }

        // 9. Motivation / Thought
        if (cleanInput.contains(Regex("\\b(motivate|quote|thought|suvichar|shayari|inspiration)\\b"))) {
            val quotes = listOf(
                "Koshish karne walon ki kabhi haar nahi hoti!",
                "Success is not final, failure is not fatal: it is the courage to continue that counts.",
                "Har sapna sach ho sakta hai gar aapme use poora karne ka jazba ho."
            )
            return ResponseResult(quotes.random(), targetLang, "MOTIVATION")
        }

        // 10. Fallback Smart Response
        return when (targetLang) {
            "hi" -> ResponseResult("मैंने आपकी बात सुनी: \"$input\"। मैं आपके निर्देश पर कार्य कर रही हूँ। जेमिनी ऑनलाइन AI मोड ऑन करने पर और भी विस्तृत उत्तर मिल सकते हैं!", "hi", "FALLBACK")
            "en" -> ResponseResult("I received your request: \"$input\". Processing with LISHA local engine. Enable Gemini Online AI mode for unlimited intelligence!", "en", "FALLBACK")
            else -> ResponseResult("Aapne kaha: \"$input\". Main ispar kaam kar rahi hoon. High-level questions ke liye aap Settings se Online Gemini AI Mode turn on kar sakte hain!", "hinglish", "FALLBACK")
        }
    }

    private fun containsHindiCharacters(text: String): Boolean {
        return text.any { it in '\u0900'..'\u097F' }
    }

    private fun trySolveMath(input: String): String? {
        val clean = input.replace("calculate", "").replace("what is", "").replace("plus", "+")
            .replace("minus", "-").replace("multiply by", "*").replace("times", "*")
            .replace("divided by", "/").trim()

        val exprPattern = Regex("(\\d+(?:\\.\\d+)?)\\s*([+\\-*/])\\s*(\\d+(?:\\.\\d+)?)")
        val match = exprPattern.find(clean) ?: return null

        val (num1Str, op, num2Str) = match.destructured
        val num1 = num1Str.toDoubleOrNull() ?: return null
        val num2 = num2Str.toDoubleOrNull() ?: return null

        val res = when (op) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> if (num2 != 0.0) num1 / num2 else Double.NaN
            else -> null
        } ?: return null

        return if (res % 1.0 == 0.0) res.toLong().toString() else String.format(Locale.US, "%.2f", res)
    }
}
